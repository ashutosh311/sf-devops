# SDLC 00 — Project & Story Initialisation

Handles two scenarios:

- **New project** — bootstrap from the template, scaffold the Apex framework, and initialise the first story.
- **Existing project** — scaffold artifact folders and create a flight plan for a new story.

---

## Step 1 — Determine scenario and gather details

Ask questions **one at a time**. Wait for the user's answer before asking the next question. Where a fixed set of options exists, present them as a numbered list so the user can reply with just a number.

---

### Question 1 — Scenario

Ask:

> **Which would you like to do?**
> 1. Create a brand-new project from this template
> 2. Scaffold a story on an existing project

Wait for the answer, then follow the matching path below.

---

### If the user chose **2 — existing project**

Check `README.md` for a JIRA project key. If found, skip question 2a.

Ask in sequence, one at a time:

- **2a. JIRA project key** *(skip if found in README)* — e.g. `KAN`
- **2b. JIRA feature ID** — the story key to scaffold (e.g. `KAN-6`)

Then jump straight to **Phase B**.

---

### If the user chose **1 — new project**

Run the following to derive the default target directory:

```bash
git rev-parse --show-toplevel
```

The default target directory is the **parent folder** of the path returned above. Store this as `{PARENT_DIR}`.

Ask the following questions **one at a time**, in order. Wait for each answer before asking the next:

1. **Project name** — kebab-case folder name (e.g. `acme-salesforce`)
2. **Target directory** — reply with a path, or press Enter / type `default` to use `{PARENT_DIR}`
3. **Git repository URL** *(optional)* — HTTPS or SSH URL; type `skip` or leave blank if not created yet
4. **JIRA project key** — prefix for all stories (e.g. `KAN`)
5. **First JIRA feature ID** — the story key to scaffold first (e.g. `KAN-1`)
6. **Salesforce login URL** — present as a numbered list:
   > 1. `https://login.salesforce.com` (production / Developer Edition)
   > 2. `https://test.salesforce.com` (sandbox)
   > 3. Custom My Domain URL (I'll type it)
7. **Salesforce admin username** — e.g. `admin@acme.com`
8. **Dev Hub org alias** — alias of the already-authenticated Dev Hub org
9. **Uses OmniStudio?**
   > 1. Yes
   > 2. No

Do not proceed to Phase A until all nine answers are collected. The full path of the new project is:
`{TARGET_DIR}/{PROJECT_NAME}` — use this in every Phase A step.

---

## Phase A — New project bootstrap *(skip entirely for existing projects)*

### A1 — Copy template

```bash
TEMPLATE_DIR=$(git rev-parse --show-toplevel)
NEW_PROJECT_DIR="{TARGET_DIR}/{PROJECT_NAME}"

mkdir -p "$NEW_PROJECT_DIR"

rsync -a \
  --exclude='.git/' \
  --exclude='artifacts/KAN-*/' \
  --exclude='artifacts/*/design/' \
  --exclude='artifacts/*/implementation/' \
  --exclude='artifacts/*/flight-plan.md' \
  --exclude='assets/' \
  --exclude='force-app/' \
  --exclude='config-data/' \
  --exclude='test-data/' \
  --exclude='node_modules/' \
  --exclude='.sfdx/' \
  --exclude='.sf/' \
  --exclude='sample-README.md' \
  "$TEMPLATE_DIR/" "$NEW_PROJECT_DIR/"
```

**If OmniStudio = no**, add `--exclude='vlocity/'` to the rsync flags above (one call only).

Confirm key directories arrived:

```bash
ls "$NEW_PROJECT_DIR/.github/prompts/"
ls "$NEW_PROJECT_DIR/devops/standards/"
```

> All prompts, instruction files, and standards are copied automatically — no separate setup needed.

---

### A2 — Initialise git

All commands from here run inside `{NEW_PROJECT_DIR}`.

```bash
git init
git checkout -b main
git checkout -b develop
```

**If a repository URL was provided:**

```bash
git remote add origin {REPO_URL}
```

The working branch is now `develop`. No remote verification needed at this stage.

---

### A3 — Install git hooks

```bash
sh devops/scripts/install-hooks.sh
```

Hooks enforce: no `System.debug` in Apex files, no logic in `.trigger` files, Conventional Commits format. Every team member must run this once after cloning.

---

### A4 — Update `sfdx-project.json`

Read `{NEW_PROJECT_DIR}/sfdx-project.json`. Apply:

- Add or update `name` → project name
- Update `sfdcLoginUrl` → Salesforce login URL
- Leave `sourceApiVersion` and `namespace` unchanged

---

### A5 — Scaffold Apex framework classes

Read `devops/standards/apex.md` in full before writing any class. Every class body MUST match the canonical pattern defined there exactly.

Create each file at `{NEW_PROJECT_DIR}/force-app/main/default/classes/base/`. Every class needs both a `.cls` and a `.cls-meta.xml`. The meta XML for every class is:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<ApexClass xmlns="http://soap.sforce.com/2006/04/metadata">
    <apiVersion>62.0</apiVersion>
    <status>Active</status>
</ApexClass>
```

Every class MUST include a script header (`/***...***/` block with `@description`) per `devops/standards/apex.md` section 5.

| # | File | Standard reference |
|---|------|--------------------|
| A5.1 | `TriggerHandler.cls` | Section 1 — "Base Handler Class" |
| A5.2 | `TriggerSettingSelector.cls` | Section 1 — `TriggerConfiguration__mdt` selector (cache + mockSetting + resetCache) |

**If OmniStudio = yes**, also create (patterns in `devops/standards/omniscript.md`):

| # | File |
|---|------|
| A5.7 | `IIntegrationProcedureService.cls` |
| A5.8 | `IntegrationProcedureServiceImpl.cls` |
| A5.9 | `IDecisionRuleService.cls` |
| A5.10 | `MockIntegrationProcedureService.cls` |

---

### A5b — Scaffold class subdirectories

Create the following directories with `.gitkeep` placeholder files. This enforces the project's layered architecture from day one:

```bash
NEW_PROJECT_DIR="{TARGET_DIR}/{PROJECT_NAME}"
BASE="$NEW_PROJECT_DIR/force-app/main/default/classes"

for DIR in domains selectors services tests mocks controllers; do
  mkdir -p "$BASE/$DIR"
  touch "$BASE/$DIR/.gitkeep"
done
```

| Directory | Purpose |
|-----------|---------|
| `base/` | Framework classes — TriggerHandler, TriggerSettingSelector |
| `domains/` | Trigger handler classes (`{Object}TriggerHandler.cls`) |
| `selectors/` | Selector classes — all SOQL lives here only |
| `services/` | Service classes — business logic, registered DML via UnitOfWork |
| `tests/` | Test classes (`{ClassName}Test.cls`) |
| `mocks/` | Mock / stub classes used only in tests |
| `controllers/` | LWC / Aura controller classes |

---

### A6 — Scaffold supporting metadata

Read `devops/standards/apex.md` sections 1, 2, and 3 for field definitions. Follow SFDX source format per `devops/standards/data-model.md`: one `.field-meta.xml` per field inside a `fields/` subdirectory.

Create in `{NEW_PROJECT_DIR}/force-app/main/default/objects/`:

**`TriggerConfiguration__mdt`** — `SObjectName__c` (Text 255, required), `IsActive__c` (Checkbox, default true), `BeforeInsert__c`, `AfterInsert__c`, `BeforeUpdate__c`, `AfterUpdate__c`, `BeforeDelete__c`, `AfterDelete__c`, `AfterUndelete__c` (all Checkbox, default false), `ExecutionOrder__c` (Number 18,0).

Only scaffold `TriggerConfiguration__mdt` here. Do **not** create `FeatureToggle__mdt` or `Log__e` — these are added per project when needed.

---

### A7 — Update README.md

> **⚠️ Tool requirement:** Write README.md using the `create_file` or `insert_edit_into_file` tool — **never** via a shell heredoc or inline Python one-liner. Both approaches can hang the terminal and require a manual Ctrl+C to recover.

Read `{NEW_PROJECT_DIR}/sample-README.md` in full. Replace the entire content of `{NEW_PROJECT_DIR}/README.md` with the contents of `sample-README.md`, substituting the following placeholders:

| Placeholder | Value |
|-------------|-------|
| `<PROJECT-NAME>` | `{PROJECT_NAME}` |
| `<devops-lead contact email>` | `{ADMIN_USERNAME}` |
| `<CLIENT-NAME>` | derived from the project name (e.g. `acme` from `acme-salesforce`) |
| `<alias>` | the Salesforce org alias the developer will use |

Do not alter any other content — preserve all headings, instructions, and formatting from `sample-README.md` exactly.

---

## Phase B — Story initialisation *(always runs)*

### B1 — Update `sfdx-project.json` name

If the `name` field is not already set to the project name, update it now. Skip if already correct.

---

### B2 — Scaffold artifact folders

Create the following with `.gitkeep` placeholder files:

```
artifacts/{FEATURE-ID}/design/.gitkeep
artifacts/{FEATURE-ID}/implementation/.gitkeep
```

The `design/` subfolder will hold: `requirements.md`, `refinement-notes.md`, `sf-discovery.md`, `solution-design.md`, `test-plan.md`.  
The `implementation/` subfolder will hold: `deployment-record.md`.

---

### B3 — Create flight plan

Copy `.github/templates/flight-plan-template.md` to `artifacts/{FEATURE-ID}/flight-plan.md`.

Fill in:
- `{JIRA-KEY}` — the feature ID
- `{Story Title}` — fetch from JIRA using `getJiraIssue`, or leave as `{Story Title}` if unavailable
- `{JIRA-URL}` — the full JIRA issue URL
- `{date}` — today's date
- All stage rows set to `pending`

---

### B4 — Commit

**New project** — commit everything as the initial commit:

```bash
git add .
git -c commit.gpgsign=false commit -m "chore({JIRA_KEY}): initialise project from sf-uki-devops template"
```

If a repository URL was provided, push:

```bash
git push -u origin develop
```

**Existing project** — commit only the new artifact files:

```bash
git add artifacts/{FEATURE-ID}/
git -c commit.gpgsign=false commit -m "chore({FEATURE-ID}): scaffold artifact folders and flight plan"
```

---

### B5 — Present summary

**For a new project:**

```
✅ New project created successfully

📁 Location:         {NEW_PROJECT_DIR}
🔗 Git remote:       {REPO_URL — or "not configured yet"}
☁️  Salesforce org:  {LOGIN_URL}  ({ADMIN_USERNAME})
🏢 Dev Hub alias:    {DEVHUB_ALIAS}
🏷️  JIRA key:        {JIRA_KEY}
🔷 OmniStudio:       {yes/no}

Framework scaffolded:
  ✅ TriggerHandler.cls / TriggerSettingSelector.cls
  [If OmniStudio:]
  ✅ IIntegrationProcedureService.cls / IntegrationProcedureServiceImpl.cls
  ✅ IDecisionRuleService.cls / MockIntegrationProcedureService.cls
  ✅ TriggerConfiguration__mdt (9 fields)

One-time setup (run inside the new project):
  sh devops/scripts/install-hooks.sh
  sf org login web --alias <alias> --instance-url {LOGIN_URL} --set-default
  sf org login web --alias {DEVHUB_ALIAS} --set-default-dev-hub
```

**For both new and existing projects, always append:**

```
Story initialised:
  artifacts/{FEATURE-ID}/design/        ← planning artifacts land here
  artifacts/{FEATURE-ID}/implementation/ ← deployment record lands here
  artifacts/{FEATURE-ID}/flight-plan.md ← progress tracker

Next steps:
  1. #sdlc/01-analyze-story  — extract requirements
  2. #sdlc/02-refine-story   — refine scope and MoSCoW
  3. #sdlc/03-sf-discover    — investigate the target org
  4. #sdlc/04-design         — produce the solution design
  5. #sdlc/05-add-solution-design — create JIRA sub-tasks
  6. #sdlc/06-test-plan      — generate the test plan
  7. #sdlc/07-implement-solution — build and deploy

To scaffold folders for another story, re-run #sdlc/00-setup with the new feature ID.
```
